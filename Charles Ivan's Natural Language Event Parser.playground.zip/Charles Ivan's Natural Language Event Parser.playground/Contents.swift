//Natural Language Parser AI
//by charles ivan mozar

import Foundation

//Event data extraction

let statementA: NSString = "I'll have dinner with John and Kate on April 11 at 7:24 PM"
let statementB: NSString = "Football at 8:40 AM on June 22 2016"
let statementC: NSString = "We'll have our annual family dinner on December 25 2016 at 12:30 AM"
let statementD: NSString = "Coding Session on November 11"
let statementE: NSString = "I'll Jog at 6:35 AM this April 11"

class Event {
    var name: String?
    var month: String?
    var day: Int?
    var year: Int?
    var hour: Int?
    var minute: Int?
    var timeIdentifier: String?

    init() {
        name = String()
        month = String()
        day = 0
        year = 0
        hour = 0
        day = 0
        minute = 0
        timeIdentifier = String()
    }
    
}

func extractDataFromQuery( query: NSString = "" ) -> Event {
    
    let newEvent = Event()
    var unprocessedQuery: NSString = query.lowercaseString
    let timespaceDescriber = [ "on", "during", "when", "where", "this" ] //possible date describers
    var containsDateInfo = false
    var isYearDescribed = false
    
    //extract date information first
    for describer in timespaceDescriber {
        if ( unprocessedQuery.containsString( describer ) ) {
            containsDateInfo = true
            let rangeOfDescriber = unprocessedQuery.rangeOfString( describer , options: .BackwardsSearch )
            unprocessedQuery = unprocessedQuery.stringByReplacingCharactersInRange( rangeOfDescriber, withString: "" )
        }
    }
    
    //detect month names in query
    if containsDateInfo {
        let monthNames = [ "january", "february", "march", "april" , "may", "june", "july", "august", "september", "october", "november", "december" ]
        for month in monthNames {
            
            //if the function had detected a month in the query, perform the operation below
            if ( unprocessedQuery.containsString( month ) ) {
                
                //extract date information
                let monthInfoRange = unprocessedQuery.rangeOfString( month )
                let dayRange = NSMakeRange( monthInfoRange.location + monthInfoRange.length, 3 )
                let day = unprocessedQuery.substringWithRange( dayRange )
                let yearRange = NSMakeRange( monthInfoRange.location+monthInfoRange.length+4 , 4)
                
                if ( query.length > yearRange.length+yearRange.location ) {
                    //check if a year is being described ( if the next 4 characters are castable to Integers, it is possible that it is a year )
                    if ( Int( unprocessedQuery.substringWithRange( yearRange ) ) != nil ) {
                        isYearDescribed = true
                    }
                }
                
                //extract described date information
                let describedDay = Int(day.stringByReplacingOccurrencesOfString(" ", withString: "")) //terminate white space
                let describedMonth = month
                let describedYear = isYearDescribed ? Int( unprocessedQuery.substringWithRange( yearRange ) ) : 0
                
                newEvent.month = describedMonth
                newEvent.day = describedDay!
                newEvent.year = isYearDescribed ? describedYear! : nil
                
                let describedDate = isYearDescribed ? "\(describedMonth) \(describedDay!) \(describedYear!)" : "\(describedMonth) \(describedDay!)"
                
                //remove date from unprocessed query
                unprocessedQuery = unprocessedQuery.stringByReplacingOccurrencesOfString( describedDate, withString: "" )
                
            }
        }
    }
    
    //does the query contains time information? if so proceed executing the operation below
    if ( unprocessedQuery.containsString( "at" ) ) {
        
        var timeSearchFunction: NSString = unprocessedQuery
        
        while ( timeSearchFunction.containsString( "at" )) {
            
            var extraSpace = 0 //used for two digit hour integers
            
            //obtain time information
            let timeDescriber = timeSearchFunction.rangeOfString( "at" )
            let hourCoordinates = NSMakeRange( timeDescriber.location+timeDescriber.length+1 , 2 )
            
            //check if the current instance of at describes a time property
            var hourStr = timeSearchFunction.substringWithRange( hourCoordinates )
            
            if ( hourStr.containsString( ":" ) ) { //the hour integer contains only one digit
                hourStr = hourStr.stringByReplacingOccurrencesOfString( ":", withString: "" )
            } else {
                extraSpace = 1 //two digit integer
            }
            
            let minuteCoordinates = NSMakeRange( timeDescriber.location+timeDescriber.length+3+extraSpace,  2 )
            let minuteStr = timeSearchFunction.substringWithRange( minuteCoordinates )
            
            let timeIdentifierCoordinates = NSMakeRange( timeDescriber.location+timeDescriber.length+6+extraSpace , 2 )
            let timeIdentifier = timeSearchFunction.substringWithRange( timeIdentifierCoordinates ).uppercaseString
            
            if (( Int( hourStr ) != nil ) && ( Int( minuteStr ) != nil )) {
                
                let describedHour = Int( hourStr )
                let describedMinute = Int( minuteStr )
                let describedIdentifier = timeIdentifier
                
                let fullTime = "at \(describedHour!):\(describedMinute!) \(describedIdentifier)".lowercaseString
                
                //set event time properties
                newEvent.minute = describedMinute!
                newEvent.hour = describedHour!
                newEvent.timeIdentifier = describedIdentifier
                
                //remove from unprocessed query
                unprocessedQuery = unprocessedQuery.stringByReplacingOccurrencesOfString( fullTime, withString: "" )
                
            }
            
            timeSearchFunction = timeSearchFunction.stringByReplacingCharactersInRange( timeDescriber, withString: "" )
            
        }
        
    }
    
    //after time and date processing, it will expose the event's name, filter out unneccessary language idiosyncrasies
    let extraWords = [ "i'll", "we'll", "let's" ]
    
    for ew in extraWords {
        unprocessedQuery = unprocessedQuery.stringByReplacingOccurrencesOfString( ew, withString: "" )
    }
    
    //set event name
    newEvent.name = unprocessedQuery as String
    
    return newEvent
}

//test

statementA
let eventA = extractDataFromQuery( statementA )
eventA.name
eventA.month
eventA.day
eventA.year
eventA.hour
eventA.minute
eventA.timeIdentifier

statementB
let eventB = extractDataFromQuery( statementB )
eventB.name
eventB.month
eventB.day
eventB.year
eventB.hour
eventB.minute
eventB.timeIdentifier

statementC
let eventC = extractDataFromQuery( statementC )
eventC.name
eventC.month
eventC.day
eventC.year
eventC.hour
eventC.minute
eventC.timeIdentifier

statementD
let eventD = extractDataFromQuery( statementD )
eventD.name
eventD.month
eventD.day
eventD.year
eventD.hour
eventD.minute
eventD.timeIdentifier

statementE
let eventE = extractDataFromQuery( statementE )
eventE.name
eventE.month
eventE.day
eventE.year
eventE.hour
eventE.minute
eventE.timeIdentifier



